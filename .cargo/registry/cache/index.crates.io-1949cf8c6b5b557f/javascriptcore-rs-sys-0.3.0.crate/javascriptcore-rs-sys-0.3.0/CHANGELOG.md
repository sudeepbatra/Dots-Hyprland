# Changelog

## \[0.3.0]

- Update Gir files
  - [3262e96](https://github.com/tauri-apps/javascriptcore-rs/commit/3262e96efc1cd6a640b81368255f3ae9325b2170) Bump version on 2021-10-04
