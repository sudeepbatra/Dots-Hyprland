# Changelog

## \[0.15.0]

- Update sys crate to latest gir.
  - [e74374e](https://github.com/tauri-apps/javascriptcore-rs/commit/e74374e9ad6da48a63c457ef8bf21e147e176479) Bump sys crate version on 2021-10-05
