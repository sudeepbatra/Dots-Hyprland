# Changelog

## \[0.15.1]

- Re-export all traits to public.
  - [4951e34](https://github.com/tauri-apps/javascriptcore-rs/commit/4951e345dafd677efeb79e42a63b5ff46baa1111) Re-export all traits to public on 2021-10-06

## \[0.15.0]

- Update webkit2gtk-rs with latest gir.
  - [bfd8a39](https://github.com/tauri-apps/javascriptcore-rs/commit/bfd8a397a4a1f2bfc150f2aaf90230c166fc6415) Bump version of webkit2gtk-rs on 2021-10-05
