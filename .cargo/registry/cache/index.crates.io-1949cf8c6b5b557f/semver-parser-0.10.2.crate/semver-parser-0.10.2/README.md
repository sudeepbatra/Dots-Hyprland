# `semver-parser`

Parsing for the semver spec.

We'll have better docs at 1.0.
