#![cfg_attr(feature = "dox", feature(doc_cfg))]

pub use auto::{traits::*, *};

mod auto;
